# 🐾 PetsGo - App Mobile Premium para Serviços Pet

<div align="center">

**O aplicativo mobile mais bonito e profissional para serviços pet**

Design Ultra Premium • Animações Cinematográficas • UI/UX de Big Tech 2025

[Features](#features) • [Tech Stack](#tech-stack) • [Getting Started](#getting-started) • [Screens](#screens)

</div>

---

## ✨ Features

### 🎨 Design Premium
- **Design System Profissional** - Paleta de cores sofisticada e consistente
- **Tipografia Elegante** - Hierarquia visual clara e espaçamentos confortáveis
- **Sombras e Elevações** - Depth visual com sombras sutis e profissionais
- **Bordas Arredondadas** - UI moderna e amigável

### 🎬 Animações & Microinterações
- **Animações Cinematográficas** - Transições suaves com React Native Reanimated
- **Microinterações Premium** - Feedback visual em todos os elementos
- **Gestos Touch Nativos** - Swipe, pull-to-refresh e press animations
- **Loading States** - Skeleton loaders e activity indicators elegantes

### 📱 Telas Completas

#### Onboarding & Autenticação
- ✅ Tela de Intro Animada (3 slides com animações)
- ✅ Tela de Criar Conta (com validação visual)
- ✅ Tela de Login (social login incluído)
- ✅ Tela de Recuperar Senha

#### Core Features
- ✅ **Home** - Localização, categorias, lojas próximas, banners
- ✅ **Loja** - Hero image, tabs (Produtos/Serviços/Avaliações/Info)
- ✅ **Carrinho** - Gestão de itens, cálculo automático
- ✅ **Agendamento** - Calendário interativo, seleção de horários
- ✅ **Checkout** - Endereço, pagamento, resumo
- ✅ **Pedidos** - Histórico e rastreamento em tempo real
- ✅ **Favoritos** - Lojas favoritas
- ✅ **Perfil** - Dados, endereços, pagamentos, suporte

### 🎯 Navegação
- **Expo Router** - File-based routing
- **Bottom Tabs** - 4 tabs principais (Home, Pedidos, Favoritos, Perfil)
- **Stack Navigation** - Navegação fluida entre telas
- **Transições Animadas** - Slide e fade effects

## 🛠 Tech Stack

### Core
- **React Native** - Framework mobile multiplataforma
- **Expo** (SDK 54+) - Desenvolvimento e build
- **Expo Router** - Navegação file-based
- **TypeScript** - Type safety (ready)

### UI & Animations
- **React Native Reanimated** - Animações performáticas
- **React Native Gesture Handler** - Gestos touch nativos
- **Expo Linear Gradient** - Gradientes suaves
- **@expo/vector-icons** - Ícones (Ionicons, Material, FontAwesome)

### State & Data
- **Mock Data** - Dados de exemplo para demonstração
- **React Hooks** - Gerenciamento de estado local

## 🚀 Getting Started

### Prerequisites
```bash
Node.js 20+ installed
npm or yarn
```

### Installation

```bash
# Clone o repositório
git clone <repository-url>

# Entre na pasta do projeto
cd PetsGo

# Instale as dependências
npm install --legacy-peer-deps

# Inicie o projeto
npm run web      # Para rodar no navegador (porta 5000)
npm run android  # Para Android (requer Android Studio)
npm run ios      # Para iOS (requer macOS + Xcode)
```

### Development

```bash
# Desenvolvimento web (porta 5000)
npm run web

# Abrir no Expo Go (mobile)
npm start

# Build para produção
expo build:android
expo build:ios
```

## 📱 Screens

### 1. Onboarding
- Intro com 3 slides animados
- Login com social authentication
- Registro completo
- Recuperação de senha

### 2. Home
- Header com localização
- Barra de busca
- Carrossel de categorias pet
- Banner promocional
- Lista de lojas próximas

### 3. Loja
- Hero image grande
- Informações da loja
- Tabs: Produtos, Serviços, Avaliações, Info
- Cards de produtos com preços
- Agendamento de serviços

### 4. Carrinho & Checkout
- Lista de itens
- Controles de quantidade
- Cálculo automático
- Seleção de endereço
- Método de pagamento
- Resumo do pedido

### 5. Agendamento
- Calendário interativo
- Grid de horários disponíveis
- Confirmação visual

### 6. Pedidos
- Lista de histórico
- Rastreamento em tempo real
- Status animado
- Avaliação pós-entrega

### 7. Perfil
- Dados pessoais
- Endereços salvos
- Métodos de pagamento
- Suporte e chat
- Configurações

## 🎨 Design System

### Colors
```javascript
Primary: #4F5DFF    // Roxo vibrante
Secondary: #7C8BFF  // Roxo claro
Accent: #00C2A8     // Verde água
Background: #F5F6FA // Cinza claro
Text: #1A1D29       // Quase preto
```

### Typography
- **Headings**: Bold/Extrabold, 24-40px
- **Body**: Regular/Medium, 15-17px
- **Captions**: Regular, 11-13px

### Spacing
- Sistema baseado em múltiplos de 4px (4, 8, 12, 16, 20, 24, 32, 40, 48)

### Shadows
- Subtle elevations para depth visual
- Colored shadows no primary color

## 📦 Components

### Core Components
- `Button` - Gradientes, loading states, variantes
- `Input` - Floating labels, validação, máscaras
- `Card` - Elevação, press animations
- `Badge` - Status indicators
- `PressableScale` - Press animations reutilizáveis
- `SkeletonLoader` - Loading placeholders
- `AnimatedGradient` - Gradientes animados

### Feature Components
- `StoreCard` - Cards de lojas com informações
- `ProductCard` - Cards de produtos
- `CategoryCard` - Cards de categorias
- `OrderCard` - Cards de pedidos

## 🌐 Web Support

O app roda perfeitamente no navegador graças ao Expo Web:
- **URL**: http://localhost:5000
- **Hot Reload**: Automático
- **Responsive**: Mobile-first design

## 📱 Mobile Support

### Android
- Build via Expo EAS
- APK ou AAB
- Play Store ready

### iOS
- Build via Expo EAS (ou Xcode)
- IPA file
- App Store ready

## 🎯 Future Features

- [ ] Integração com APIs reais
- [ ] Sistema de pagamento (Stripe/PagSeguro)
- [ ] Chat em tempo real
- [ ] Notificações push
- [ ] Geolocalização real
- [ ] Reviews e avaliações
- [ ] Sistema de pontos/cashback

## 📄 License

MIT License - Sinta-se livre para usar este projeto!

## 🤝 Contributing

Contribuições são bem-vindas! 

---

<div align="center">
  
**Feito com ❤️ e muito ☕**

Design Premium • Código Limpo • Performance Otimizada

</div>
