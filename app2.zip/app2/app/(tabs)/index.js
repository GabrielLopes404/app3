import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';
import HeroSection from '../../components/HeroSection';
import QuickActions from '../../components/QuickActions';
import SectionHeader from '../../components/SectionHeader';
import BannerCarousel from '../../components/BannerCarousel';
import CategoryCard from '../../components/CategoryCard';
import StoreCardPremium from '../../components/StoreCardPremium';
import { banners, categories, stores } from '../../constants/mockData';

export default function HomeScreen() {
  const router = useRouter();
  const [location, setLocation] = useState('Rua das Flores, 123');

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.locationButton} activeOpacity={0.8}>
          <Ionicons name="location" size={20} color={Colors.primary} />
          <View style={styles.locationTextContainer}>
            <Text style={styles.locationLabel}>Localização</Text>
            <Text style={styles.locationText} numberOfLines={1}>
              {location}
            </Text>
          </View>
          <Ionicons name="chevron-down" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.notificationButton} activeOpacity={0.8}>
          <Ionicons name="notifications-outline" size={24} color={Colors.textPrimary} />
          <View style={styles.notificationBadge} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.searchContainer}>
          <TouchableOpacity style={styles.searchBar} activeOpacity={0.8}>
            <Ionicons name="search" size={20} color={Colors.textSecondary} />
            <Text style={styles.searchPlaceholder}>
              Buscar produtos, serviços...
            </Text>
          </TouchableOpacity>
        </View>

        <HeroSection onPress={() => console.log('Hero CTA pressed')} />

        <QuickActions onActionPress={(action) => console.log('Action:', action.label)} />

        <BannerCarousel 
          banners={banners} 
          onBannerPress={(banner) => console.log('Banner pressed:', banner)}
        />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Categorias</Text>
          
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesContainer}
          >
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                icon={<Ionicons name={category.icon} size={32} color={category.color} />}
                title={category.name}
                color={category.color}
                onPress={() => {}}
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Destaques"
            subtitle="As melhores lojas perto de você"
            actionText="Ver todos"
            onActionPress={() => console.log('See all featured')}
          />

          {stores.filter(s => s.isFeatured).map((store) => (
            <StoreCardPremium
              key={store.id}
              store={store}
              onPress={() => router.push(`/store/${store.id}`)}
            />
          ))}
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Perto de você"
            subtitle={`${stores.filter(s => !s.isFeatured).length} lojas disponíveis`}
          />

          {stores.filter(s => !s.isFeatured).map((store) => (
            <StoreCardPremium
              key={store.id}
              store={store}
              onPress={() => router.push(`/store/${store.id}`)}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  locationButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  locationTextContainer: {
    flex: 1,
  },
  locationLabel: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
  },
  locationText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  notificationButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing.xl,
  },
  searchContainer: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    paddingTop: Spacing.lg,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
    ...Shadows.small,
  },
  searchPlaceholder: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  section: {
    marginBottom: Spacing.xxl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  seeAll: {
    fontSize: FontSizes.sm,
    color: Colors.primary,
    fontWeight: FontWeights.semibold,
  },
  categoriesContainer: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
});
