import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const actions = [
  { id: '1', icon: 'cart', label: 'Produtos', color: Colors.primary },
  { id: '2', icon: 'cut', label: 'Banho & Tosa', color: '#FF6B6B' },
  { id: '3', icon: 'medical', label: 'Veterinário', color: '#4ECDC4' },
  { id: '4', icon: 'walk', label: 'Passeios', color: '#95E1D3' },
  { id: '5', icon: 'bed', label: 'Hotel', color: '#FFB84D' },
  { id: '6', icon: 'heart', label: 'Adoção', color: '#F38181' },
];

export default function QuickActions({ onActionPress }) {
  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>Serviços</Text>
      
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {actions.map((action) => (
          <TouchableOpacity
            key={action.id}
            style={styles.actionCard}
            activeOpacity={0.8}
            onPress={() => onActionPress?.(action)}
          >
            <View style={[styles.iconContainer, { backgroundColor: `${action.color}15` }]}>
              <Ionicons name={action.icon} size={24} color={action.color} />
            </View>
            <Text style={styles.actionLabel}>{action.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
    marginHorizontal: Spacing.lg,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  actionCard: {
    alignItems: 'center',
    width: 80,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xs,
    ...Shadows.small,
  },
  actionLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
    textAlign: 'center',
  },
});
